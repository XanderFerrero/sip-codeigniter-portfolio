#pragma once
#include <SFML/Graphics.hpp>
#include "Global.hpp"

namespace G
{
	class DText :public sf::Text
	{
		std::stringstream s;
		ToolRef data;
	public:

		DText(ToolRef data) : sf::Text() {
			this->data = data;
		};
	
		template <typename T>
		DText& operator << (T v)
		{
			s << v;

			this->setString(s.str());
			this->setOrigin(this->getLocalBounds().getPosition());

			return *this;
		}

		void render()
		{
			data->window.draw(*this);
			s.str("");
		}

	};
}