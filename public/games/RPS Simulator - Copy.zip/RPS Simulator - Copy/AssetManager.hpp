#pragma once
#include <string>
#include <vector>
#include <SFML/Graphics.hpp>

namespace G
{
	class AssetManager
	{
	private:
		std::map<std::string, sf::Font> fonts;
		std::map<std::string, sf::Texture> textures;
		std::map<std::string, std::vector<sf::IntRect>> sprite_map;
	public:
		AssetManager() {};
		~AssetManager() {};
		void loadFont(std::string key, std::string path);
		void loadTexture(std::string key, std::string path);
		void setSpriteMap(std::string key, std::vector<sf::IntRect> r);
		sf::Font& getFont(std::string key);
		sf::Texture& getTexture(std::string key);
		std::vector<sf::IntRect>& getSpriteMap(std::string key);
		
	};
}

