#pragma once
#include "Global.hpp"
#include "Game.hpp"


namespace G {
	
	class Item : public sf::Sprite
	{
	public:
		ToolRef data;
		int type;
		float dtMul = 20;

		Item(ToolRef data, int type);
		
		sf::Vector2f vel;
		int closest;
		bool touchMember;

		void move();
		void draw();

	};

	typedef std::shared_ptr<Item> ItemRef;
}

