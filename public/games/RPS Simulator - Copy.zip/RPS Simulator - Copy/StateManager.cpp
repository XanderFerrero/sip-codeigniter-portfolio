#include "StateManager.hpp"

namespace G 
{
	void StateManager::checkChanges()
	{
		if (remove && !states.empty())
		{
			states.pop();
		}
		remove = false;

		if (add) {
			if (replace) {
				states.pop();
				replace = false;
			}

			states.push(std::move(newState));
			states.top()->Init();
			add = false;
		}

	}

	void StateManager::addState(StateRef state, bool replace)
	{
		newState = std::move(state);
		this->add = true;
		this->replace = replace;
	}

	void StateManager::removeState()
	{
		this->remove = true;
	}

	StateRef& StateManager::getActiveState()
	{
		return this->states.top();
	}
}