#include "Item.h"

namespace G
{
	Item::Item(ToolRef data, int type): sf::Sprite()
	{	
		this->data = data;
		this->type = type;
		
		this->setTexture(data->assetM.getTexture("rps"));
		this->scale(1,1);

		switch (type)
		{
		case 0:
			this->setTextureRect(data->assetM.getSpriteMap("rps")[0]);
			break;
		case 1:
			this->setTextureRect(data->assetM.getSpriteMap("rps")[1]);
			break;
		case 2:
			this->setTextureRect(data->assetM.getSpriteMap("rps")[2]);
			break;
		};

		this->setPosition(
			rand() % (int)(GAME_WIDTH - this->getGlobalBounds().width),
			rand() % (int)(GAME_HEIGHT - this->getGlobalBounds().height)
		);
	}

	void Item::move()
	{
		sf::Sprite::move(vel.x * data->timeStep * dtMul, vel.y * data->timeStep * dtMul);
	}

	void Item::draw()
	{
		data->window.draw(*this);
	}
}