#pragma once
#include <iostream>
#include <memory>
#include <stack>
#include <map>
#include <string>
#include <ctime>
#include <sstream>
#include <string>
#include <cstdlib>
#include <SFML/Graphics.hpp>
#include "AssetManager.hpp"
#include "InputManager.hpp"
#include "StateManager.hpp"
#include "Definitions.hpp"

#define LOG(x) std::cout << x << std::endl;

namespace G
{
	struct Tool {
		sf::RenderWindow window;
		StateManager stateM;
		AssetManager assetM;
		InputManager inputM;
		float timeStep;
	};

	typedef std::shared_ptr<Tool> ToolRef;
}