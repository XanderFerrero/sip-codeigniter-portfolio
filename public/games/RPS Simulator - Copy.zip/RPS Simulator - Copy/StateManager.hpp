#pragma once
#include <SFML/Graphics.hpp>
#include "State.hpp"
#include <stack>
#include <memory>

namespace G {
	typedef std::unique_ptr<State> StateRef;

	class StateManager
	{
	public:
		StateManager() {};
		~StateManager() {};
		StateRef& getActiveState();
		void checkChanges();
		void addState(StateRef state, bool replace = true);
		void removeState();
	private:
		std::stack<StateRef> states;
		StateRef newState;
		bool replace = false;
		bool add = false;
		bool remove = false;
	};

}

