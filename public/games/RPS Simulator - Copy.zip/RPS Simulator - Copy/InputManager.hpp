#pragma once
#include <SFML/Graphics.hpp>
namespace G {
	class InputManager
	{
	public:
		InputManager() {};
		~InputManager() {};
		bool spriteClicked(sf::Sprite s, sf::Mouse::Button btn, sf::RenderWindow& window);
		bool textClicked(sf::Text s, sf::Mouse::Button btn, sf::RenderWindow& window);

	};
}

