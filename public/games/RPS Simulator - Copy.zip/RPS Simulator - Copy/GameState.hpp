#pragma once
#include "State.hpp"
#include "Item.h"
#include "Global.hpp"
#include "DText.hpp"

namespace G {

    class GameState :
        public State
    {
    public:
        ToolRef data;
        GameState(ToolRef data);
        float magVel = 10;

        void Init() override;
        void HandleInput() override;
        void Update() override;
        void updateItems(std::vector<Item>& items, std::vector<Item>& targets);
        void Render() override;
        void Spawn(int rock, int paper, int scissors);
        void DrawItems(std::vector<Item>& items);
        bool spriteCollision(const Item& a, const Item& b);
        float distance(sf::Vector2f a, sf::Vector2f b);
        void DrawText();
        void reset();
        void HandleKeyPress();
        std::string getVictor();
    private:
        sf::Event e;
        sf::RectangleShape r;
        sf::Vector2f pos;
        DText textInfo;
        std::vector<Item> rocks = {};
        std::vector<Item> papers = {};
        std::vector<Item> scissors = {};
     
    };
}

