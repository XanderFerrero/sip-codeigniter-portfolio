#pragma once


namespace G {
	class State
	{
	public:
		State() {};
		virtual void Init() = 0;
		virtual void Update() = 0;
		virtual void Render() = 0;
		virtual void HandleInput() = 0;
	};
}

