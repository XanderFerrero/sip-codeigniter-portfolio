#pragma once
#include "Global.hpp"

namespace G
{
	

	class Game
	{
	public:
		ToolRef data = std::make_shared<Tool>();
		sf::Clock mainClock;
		Game();
		~Game() {};

		void Run();
	};
}

