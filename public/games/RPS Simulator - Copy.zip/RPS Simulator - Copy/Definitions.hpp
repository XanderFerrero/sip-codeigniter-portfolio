#pragma once

constexpr auto GAME_WIDTH = 1200;
constexpr auto GAME_HEIGHT = 800;
constexpr float FPS = 60.0f;
constexpr auto RPS_TEXTURE = "./assets/textures/objects.png";
constexpr auto FONT_TEXTURE = "./assets/fonts/pixelated.ttf";