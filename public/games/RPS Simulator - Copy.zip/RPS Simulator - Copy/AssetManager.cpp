#include "AssetManager.hpp"

namespace G
{
	void AssetManager::loadFont(std::string key, std::string path)
	{
		sf::Font f;

		if (!f.loadFromFile(path))
		{
			return;
		}
		else {
			fonts[key] = f;
		}
	}

	void AssetManager::loadTexture(std::string key, std::string path)
	{
		sf::Texture t;
		if (!t.loadFromFile(path))
		{
			return;
		}
		else {
			textures[key] = t;
		}
	}

	void AssetManager::setSpriteMap(std::string key, std::vector<sf::IntRect> r)
	{
		sprite_map[key] = r;
	}

	sf::Font& AssetManager::getFont(std::string key)
	{
		return fonts[key];
	}

	sf::Texture& AssetManager::getTexture(std::string key)
	{
		return textures[key];
	}

	std::vector<sf::IntRect>& AssetManager::getSpriteMap(std::string key)
	{
		return sprite_map[key];
	}
}