#include "InputManager.hpp"

namespace G
{
	bool InputManager::spriteClicked(sf::Sprite s, sf::Mouse::Button btn, sf::RenderWindow& window)
	{
		if (sf::Mouse::isButtonPressed(btn)) {
			sf::IntRect area(s.getPosition().x, s.getPosition().y, s.getGlobalBounds().width, s.getGlobalBounds().height);
			if (area.contains(sf::Mouse::getPosition(window)))
			{
				return true;
			}
		}
		return false;
	}
	bool InputManager::textClicked(sf::Text t, sf::Mouse::Button btn, sf::RenderWindow& window)
	{
		if (sf::Mouse::isButtonPressed(btn)) {
			sf::IntRect area(t.getPosition().x, t.getPosition().y, t.getGlobalBounds().width, t.getGlobalBounds().height);
			if (area.contains(sf::Mouse::getPosition(window)))
			{
				return true;
			}
		}
		return false;
	}




}