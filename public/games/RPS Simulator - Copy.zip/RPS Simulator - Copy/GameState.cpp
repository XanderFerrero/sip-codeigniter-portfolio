#include "GameState.hpp"
#include "Item.h"

namespace G
{
	GameState::GameState(ToolRef data)
		: textInfo(data)
	{
		this->data = data;
	}	

	void GameState::Init()
	{
		data->assetM.loadTexture("rps",RPS_TEXTURE);
		data->assetM.loadFont("font", FONT_TEXTURE);
		data->assetM.setSpriteMap("rps", 
			{
				sf::IntRect(0, 0, 20, 20),
				sf::IntRect(20, 0, 20, 20),
				sf::IntRect(40, 0, 20, 20),
			});

		textInfo.setFillColor(sf::Color::Black);
		textInfo.setFont(data->assetM.getFont("font"));
		textInfo.setCharacterSize(20);
		Spawn(50, 50, 50);
	}

	void GameState::HandleInput()
	{
		while (data->window.pollEvent(e))
		{
			switch (e.type)
			{
			case sf::Event::Closed:
				data->window.close();
				break;
			case sf::Event::KeyPressed:
				HandleKeyPress();
			}

		}
	}

	void GameState::HandleKeyPress()
	{
		switch (e.key.code)
		{
		case sf::Keyboard::E:
			data->window.close();	
			break;
		case sf::Keyboard::R:
			reset();
			break;
		}
	}

	void GameState::Update()
	{
		updateItems(rocks, scissors);
		updateItems(scissors, papers);
		updateItems(papers, rocks);
	}

	void GameState::updateItems(std::vector<Item>& items, std::vector<Item>& targets)
	{
		for (int i = 0; i < items.size(); i++)
		{
			int closest = 0;
			items[i].vel.x = 0;
			items[i].vel.y = 0;
			//reset velocities;

			if (targets.size() != 0)
			{
				for (int j = 0; j < targets.size(); j++)
				{
					if(distance(items[i].getPosition(), targets[closest].getPosition()) >
						distance(items[i].getPosition(), targets[j].getPosition())) {
						closest = j;
					}
				}
				float r = distance(items[i].getPosition(), targets[closest].getPosition());
				float dx = targets[closest].getPosition().x - items[i].getPosition().x;
				float dy = targets[closest].getPosition().y - items[i].getPosition().y;

				items[i].vel.x = magVel *  dx / r;
				items[i].vel.y = magVel * dy / r;
			}



			for (int j = 0; j < items.size(); j++)
			{
				if (i != j)
				{
					if (items[i].getGlobalBounds().intersects(items[j].getGlobalBounds()))
					{
						float r = distance(items[i].getPosition(), items[j].getPosition());
						float dx = items[j].getPosition().x - items[i].getPosition().x;
						float dy = items[j].getPosition().y - items[i].getPosition().y;

						items[i].vel.x = -magVel * dx / r;
						items[i].vel.y = -magVel * dy / r;

						break;
					}
				}
			}

			//check targets
			items[i].move();

			for (int j = 0; j < targets.size() ; j++)
			{
				if (items[i].getGlobalBounds().intersects(targets[j].getGlobalBounds()))
				{
					items.push_back(Item(data, items[i].type));
					items[items.size() - 1].setPosition(targets[j].getPosition());
					targets.erase(targets.begin() + j);
					j = 0;
				}
			}
		}
	}

	void GameState::Render()
	{
		data->window.clear(sf::Color(192, 192, 192));
		DrawItems(rocks);
		DrawItems(papers);
		DrawItems(scissors);
		DrawText();
		data->window.display();
	}

	void GameState::DrawText()
	{
		textInfo << 1 / data->timeStep << " FPS";
		textInfo.render();

		textInfo << "Rock: " << rocks.size();
		textInfo.move(0, textInfo.getGlobalBounds().getSize().y * 2);
		textInfo.render();

		textInfo << "Paper: " << papers.size();
		textInfo.move(0, textInfo.getGlobalBounds().getSize().y);
		textInfo.render();

		textInfo << "Scissors: " << scissors.size();
		textInfo.move(0, textInfo.getGlobalBounds().getSize().y);
		textInfo.render();

		if (getVictor() != "")
		{
			textInfo.setCharacterSize(100);
			textInfo << getVictor() << " WINS!";
			textInfo.setPosition((GAME_WIDTH - textInfo.getGlobalBounds().width) / 2, (GAME_HEIGHT - textInfo.getCharacterSize()) / 2);
			textInfo.setFillColor(sf::Color::Red);
			textInfo.render();
		}
			
		textInfo.setPosition(0, 0);
		textInfo.setFillColor(sf::Color::Black);
		textInfo.setCharacterSize(20);
	}

	void GameState::DrawItems(std::vector<Item>& items)
	{
		for (Item& i : items)
		{
			i.draw();
		}
	}

	void GameState::Spawn(int r, int p, int s)
	{
		for (int i = 0; i < r; i++)
		{
			rocks.push_back(Item(data, 0));
		}

		for (int i = 0; i < p; i++)
		{
			papers.push_back(Item(data, 1));
		}
		
		for (int i = 0; i < s; i++)
		{
			scissors.push_back(Item(data, 2));
		}
	
	}

	float GameState::distance(sf::Vector2f a, sf::Vector2f b)
	{
		return std::sqrt(std::pow(b.x - a.x, 2) + std::pow(b.y - a.y, 2));
	}

	bool GameState::spriteCollision(const Item& a, const Item& b)
	{
		return a.getGlobalBounds().intersects(b.getGlobalBounds());
	}

	std::string GameState::getVictor()
	{
		int total = rocks.size() + papers.size() + scissors.size();
		if (total == rocks.size())
		{
			return "ROCK";
		}
		if (total == papers.size())
		{
			return "PAPER";
		}
		if (total == scissors.size())
		{
			return "SCISSORS";
		}

		return "";
	}

	void GameState::reset()
	{
		rocks.clear();
		papers.clear();
		scissors.clear();
		Spawn(100, 100, 100);
	}
}