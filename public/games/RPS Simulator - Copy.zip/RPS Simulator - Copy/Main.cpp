#include "Game.hpp"

using namespace G;

int main(int argc, char** argv)
{
	Game g;

	return EXIT_SUCCESS;
}