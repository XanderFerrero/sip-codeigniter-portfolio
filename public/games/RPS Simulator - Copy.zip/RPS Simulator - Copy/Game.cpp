#include "Game.hpp"
#include "GameState.hpp"

namespace G
{
	Game::Game()
	{
		srand(time(0)); //randomness
		data->window.create(sf::VideoMode(GAME_WIDTH, GAME_HEIGHT), "RPS SIMULATOR", sf::Style::Titlebar | sf::Style::Close);
		data->stateM.addState(StateRef(new GameState(data)), false);
		data->timeStep = 1 / FPS;
		Run();
	}

	void Game::Run() {
		float frameTime, timeI, timeF;
		
		timeI = mainClock.getElapsedTime().asSeconds();

		while (data->window.isOpen())
		{
			data->stateM.checkChanges();
			timeF = mainClock.getElapsedTime().asSeconds();
			data->timeStep = timeF - timeI;
			timeI = timeF;
			
			data->stateM.getActiveState()->HandleInput();
			data->stateM.getActiveState()->Update();
			data->stateM.getActiveState()->Render();


		}

	}
}