#include "TextureManager.h"

TextureManager::TextureManager() {}
void TextureManager::loadTexture(const std::string& key, const std::string& path)
{
	sf::Texture t;
	if (t.loadFromFile(path)) {
		textureMap[key] = t;
	}
	else {
		LOG("TEXTURE DIDNT LOAD FROM: " << path);
	}
}

sf::Texture& TextureManager::getTexture(const std::string& key)
{
	return textureMap[key];
}