#pragma once
#include "Global.hpp"

class Current
{
public:

	Point mainT[4], ghostT[4], center;

	enum TM_TYPES {
		O = 0, I,S,Z,L,J,T
	};

	enum R_STATE {
		R_SPAWN = 0, R_RIGHT, R_BACK, R_LEFT
	};

	TM_TYPES type;
	TM_TYPES nextType;
	R_STATE rState;

	//press once variables
	bool rightRKeyHold = false;
	bool leftRKeyHold = false;
	bool spaceKeyHold = false;



	//object setup
	void setTetromino();
	
	//move controls
	void move(float x, float y);
	void rotate(bool right);
	void drop();
	void moveLeft();
	void moveRight();
	void rotateLeft();
	void rotateRight();
	void setGhostPos();
	int hardDrop();

	//check collisions per move
	bool tetroCollision();
	bool groundCollision();

	//check collisions per rotation
	void wallKick(R_STATE& init, R_STATE next, bool right);
	std::vector<std::vector<int>> getWallKickData(R_STATE& init, R_STATE next);

	Current();
	virtual ~Current();
};

