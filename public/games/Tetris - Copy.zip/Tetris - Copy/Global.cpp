#include "Global.hpp"

unsigned int HEIGHT = 800.f;
unsigned int WIDTH = 800.f;
const char* TITLE = "Tetris";
int ROWS = 20;
int COLUMNS = 10;
float SIZE = 40.f;

float GHOST_OUTLINE = 4.f;
int field[20][10];

int structure[7][4][2] = { 
	{ {0,0},{0,1},{1,0},{1,1} },//O
	{ {0,0},{1,0},{2,0},{3,0} },//I
	{ {0,1},{1,1},{1,0},{2,0} },//S
	{ {0,0},{1,1},{1,0},{2,1} },//Z
	{ {2,0},{0,1},{1,1},{2,1} },//L
	{ {0,0},{0,1},{1,1},{2,1} },//J
	{ {1,0},{0,1},{1,1},{2,1} }//T
};
float centers[7][2][2] = {
	{{4.5,0.5},{-0.5,-0.5}},
	{{4.5, 1.5},{-1.5,-0.5}},
	{{4,1},{-1,0}},
	{{4,1},{-1,-1}},
	{{4,1},{+1,-1}},
	{{4,1},{-1,-1}},
	{{4,1},{0,-1}},
};

const char* logo[5] = {
	"### ### ### ##  ### ###",
	" #  #    #  # #  #  #  ",
	" #  ###  #  ##   #  ###",
	" #  #    #  # #  #    #",
	" #  ###  #  # # ### ###",
	
};

void Point::setBlock(float x, float y)
{
	this->x = x;
	this->y = y;
}


sf::Vector2f roundBounds(const sf::Vector2f vector) {
	return sf::Vector2f{ std::round(vector.x), std::round(vector.y) };
}