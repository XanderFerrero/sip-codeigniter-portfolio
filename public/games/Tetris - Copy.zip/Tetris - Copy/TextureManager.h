#pragma once
#include "Global.hpp"
class TextureManager
{
	std::map<std::string, sf::Texture> textureMap;
public:
	TextureManager();
	void loadTexture(const std::string& key, const std::string& path);
	sf::Texture& getTexture(const std::string& key);
};

