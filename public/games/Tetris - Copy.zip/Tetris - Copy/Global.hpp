#pragma once
#include <iostream>
#include <sstream>
#include <vector>
#include <cmath>
#include <map>
#include <string>
#include <SFML/Graphics.hpp>
#include <string>
#include <cstdlib>


#define LOG(x) std::cout << x << "\n"
#define LOG2(x) std::cout << x;


typedef sf::Keyboard Key;

struct Point {
	float x, y;
	void setBlock(float x, float y);
};

extern unsigned int HEIGHT;
extern unsigned int WIDTH;
extern const char* TITLE;
extern int ROWS;
extern int COLUMNS;
extern float SIZE;
extern float GHOST_OUTLINE;
extern int field[20][10];
extern int structure[7][4][2];
extern float centers[7][2][2];
extern const char* logo[5];

//no semipixel rendering
extern sf::Vector2f roundBounds(const sf::Vector2f vector);
