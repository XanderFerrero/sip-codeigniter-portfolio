#pragma once
#include "Global.hpp"
#include "Current.h"
#include "DText.h"
#include "TextureManager.h"

class Game
{
private:
	TextureManager textureManager;

	float MOVE_COOLDOWN = 0.025f;
	float DEFAULT_DROP_COOLDOWN = 1.f;
	float MIN_DROP_COOLDOWN = 0.05f;
	float MAX_DROP_COOLDOWN = 1.f;
	int MAX_LEVEL = 20;
	float SOFT_DROP_COOLDOWN = 0.025f;
	float DROP_COOLDOWN = DEFAULT_DROP_COOLDOWN;

	//winstate
	enum WINSTATE {
		START, DEFAULT, LOSE
	};

	//game variables
	WINSTATE winstate = START;
	int lines_cleared = 0;
	int level = 1;
	int score = 0;
	std::string scoreText = "";


	//render text with variables
	std::stringstream ss;

	//properties
	sf::RenderWindow window;
	sf::Event e;
	sf::Clock dropTimer;
	sf::Clock moveTimer;
	sf::Clock scoreTextTimer;
	sf::Clock logoTimer;
	int logoCtr = 0;
	sf::Font font;


	Current current;

	//current and next type index need to be incremented by one 
	//because zero is nothing


	std::vector<sf::IntRect> texturePos = {
		sf::IntRect(140,0,20,20),
		sf::IntRect(0,0,20,20),
		sf::IntRect(20,0,20,20),
		sf::IntRect(40,0,20,20),
		sf::IntRect(60,0,20,20),
		sf::IntRect(80,0,20,20),
		sf::IntRect(100,0,20,20),
		sf::IntRect(120,0,20,20),

	};


	//game methods;
	void initWindow();
	void initUI();
	void initTextures();
	void eventListener();
	void keyPressedListener();
	void keyReleasedListener();
	void update();
	void render();
	void renderGame();
	void renderNextTM(sf::Vector2f initPos, int data[][2]);
	void renderUI();
	void renderGameOver();
	void renderIntro();
	void reset();

	//game updates;
	void newCurrent();
	void clear(int line);
	void clearLines();
	bool checkClear(int line);
	

public:
	Game();
	void start();
	virtual ~Game();
};

