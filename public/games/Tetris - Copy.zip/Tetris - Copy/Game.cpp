#include "Game.h"

Game::Game():
	window(sf::VideoMode(WIDTH, HEIGHT), TITLE,sf::Style::Titlebar | sf::Style::Close)
{
	for (int i = 0; i < ROWS; i++) {
		for (int j = 0; j < COLUMNS; j++) {
			field[i][j] = 0;
		}
	}
	initWindow();
	initTextures();
	initUI();
	start();
}

Game::~Game() {}

void Game::initTextures()
{
	textureManager.loadTexture("tetromino", "./tetromino.png");
}

void Game::initWindow()
{
	window.setFramerateLimit(360);
}

void Game::initUI()
{
	if (!font.loadFromFile("./fonts/pixelated.ttf")) {
		LOG("ERROR");
	}
}

void Game::start()
{
	current.setTetromino();

	while (window.isOpen()) {
		eventListener();
		window.clear(sf::Color(0, 37, 69));
		
		if (winstate == DEFAULT) {
			update();
		}
		render();
		
		window.display();
	}
}

void Game::eventListener()
{
	while (window.pollEvent(e)) {

		switch (e.type) {

		case sf::Event::Closed:
			window.close();
			break;

		case sf::Event::KeyPressed:
			keyPressedListener();
			break;

		case sf::Event::KeyReleased:
			keyReleasedListener();
		}

	}

}

void Game::keyPressedListener()
{

	if (e.key.code == Key::Enter) {
		if (winstate == LOSE || winstate == START) {
			reset();
		}
	}

	if (winstate != LOSE) {
		//movement
		switch (e.key.code) {
		case Key::Down:
			DROP_COOLDOWN = SOFT_DROP_COOLDOWN;
			break;
		case Key::Left:
			if (moveTimer.getElapsedTime().asSeconds() >= MOVE_COOLDOWN)
			{
				current.moveLeft();
				moveTimer.restart();
			}
			break;
		case Key::Right:
			if (moveTimer.getElapsedTime().asSeconds() >= MOVE_COOLDOWN)
			{
				current.moveRight();
				moveTimer.restart();
			}
			break;
		case Key::E:
			window.close();
			break;
		case Key::Up:
			if (!current.rightRKeyHold) {
				current.rotateRight();
				current.rightRKeyHold = true;
			}
			break;
		case Key::X:
			if (!current.rightRKeyHold) {
				current.rotateRight();
				current.rightRKeyHold = true;
			}
			break;
		case Key::Z:
			if (!current.leftRKeyHold) {
				current.rotateLeft();
				current.leftRKeyHold = true;
			}
			break;
		case Key::Space:
			if (!current.spaceKeyHold) {
				score += current.hardDrop() * 2;
				newCurrent();
				current.spaceKeyHold = true;
			}
			break;
		}
	}
}

void Game::keyReleasedListener()
{
	switch (e.key.code) {
	case Key::Up:
		current.rightRKeyHold = false;
		break;
	case Key::X:
		current.rightRKeyHold = false;
		break;
	case Key::Z:
		current.leftRKeyHold = false;
		break;
	case Key::Down:
		DROP_COOLDOWN = DEFAULT_DROP_COOLDOWN;
		break;
	case Key::Space:
		current.spaceKeyHold = false;
	}
}

void Game::update()
{
	current.setGhostPos();

	if (dropTimer.getElapsedTime().asSeconds() > DROP_COOLDOWN) {
		//update per drop
		current.drop();
		dropTimer.restart();

		//increase score soft drop

		if (DROP_COOLDOWN == SOFT_DROP_COOLDOWN) {
			score++;
		}

		if (current.groundCollision())
		{
			newCurrent();
		}
	}

	if (scoreTextTimer.getElapsedTime().asSeconds() > 0.5f) {
		scoreText = "";
	}
}

void Game::render()
{
	if (winstate == START) {
		renderIntro();
	}
	else {
		renderGame();
		renderUI();

		if (winstate == LOSE) {
			renderGameOver();
		}
	}
}

void Game::renderGame()
{
	sf::Sprite s;
	s.setTexture(textureManager.getTexture("tetromino"));
	s.scale(2,2);
	sf::RectangleShape r;

	//render field
	for (int i = 0; i < ROWS; ++i) {
		for (int j = 0; j < COLUMNS; ++j) {
			if (field[i][j] != 0) {
				s.setPosition(j * SIZE, i * SIZE);
				s.setTextureRect(texturePos[field[i][j]]);
				window.draw(s);
			}
		}
	}

	//render ghost
	for (int i = 0; i < 4; i++) {
		s.setColor(sf::Color(s.getColor().r, s.getColor().g, s.getColor().b, 100));
		s.setPosition(current.ghostT[i].x * SIZE, current.ghostT[i].y * SIZE);
		s.setTextureRect(texturePos[current.type + 1]);
		window.draw(s);
	}

	//render current
	for (int i = 0; i < 4; i++) {
		s.setColor(sf::Color(s.getColor().r, s.getColor().g, s.getColor().b, 255));
		s.setPosition(current.mainT[i].x * SIZE, current.mainT[i].y * SIZE);
		s.setTextureRect(texturePos[current.type + 1]);
		window.draw(s);
	}
}

void Game::renderUI()
{
	sf::RectangleShape r;
	//render right screen;
	r.setPosition(SIZE*COLUMNS,0);
	r.setSize(sf::Vector2f(SIZE * COLUMNS, SIZE * ROWS));
	r.setFillColor(sf::Color(59, 59, 57));
	window.draw(r);

	//render next container
	r.move(SIZE*2.5, SIZE*2);
	r.setSize(sf::Vector2f(SIZE*5,SIZE * 5));
	r.setFillColor(sf::Color::Black);
	window.draw(r);

	renderNextTM(r.getPosition(), structure[current.nextType]);

	//render text
	DText text;
	text.setFont(font);
	text.setCharacterSize(32);
	
	text.setString("Next");
	text.setPosition(WIDTH * 3/4, SIZE);
	window.draw(text);

	ss << "Lines: " << lines_cleared;
	text.setString(ss.str());
	ss.str("");
	text.setPosition(WIDTH * 3 / 4, SIZE * 9);
	window.draw(text);

	ss << "Level: " << level;
	text.setString(ss.str());
	ss.str("");
	text.setPosition(WIDTH * 3 / 4, SIZE * 11);
	window.draw(text);

	ss << "Score: " << score;
	text.setString(ss.str());
	ss.str("");
	text.setPosition(WIDTH * 3 / 4, SIZE * 10);
	window.draw(text);

	text.setCharacterSize(64);
	text.setString(scoreText);
	text.setPosition(WIDTH * 3 / 4, SIZE * 15);
	window.draw(text);
	
}

void Game::renderNextTM(sf::Vector2f initPos, int data[][2])
{
	sf::Sprite s;
	s.scale(2, 2);
	s.setTextureRect(texturePos[current.nextType + 1]);

	s.setTexture(textureManager.getTexture("tetromino"));

	int w = 0, h = 0;
	for (int i = 0; i < 4; i++) {
		if (data[i][0] > w) {
			w = data[i][0];
		}

		if (data[i][1] > h) {
			h = data[i][1];
		}
	}
	s.setPosition(initPos);
	s.move((SIZE*5-SIZE*(w+1))/2, (SIZE * 5 - SIZE*(h + 1)) / 2);

	int x = s.getPosition().x;
	int y = s.getPosition().y;

	for (int i = 0; i < 4; i++) {
		s.setPosition(x + data[i][0] * SIZE, y + data[i][1] * SIZE);
		window.draw(s);
	}
}

void Game::renderGameOver()
{
	sf::RectangleShape r;
	r.setSize(sf::Vector2f(500, 300));
	r.setPosition((WIDTH - r.getSize().x)/2, (HEIGHT - r.getSize().y)/2);
	r.setFillColor(sf::Color::Cyan);
	window.draw(r);

	r.setSize(sf::Vector2f(500 - 20,300 - 20));
	r.setPosition((WIDTH - r.getSize().x) / 2, (HEIGHT - r.getSize().y) / 2);
	r.setFillColor(sf::Color::Blue);
	window.draw(r);

	DText text;
	text.setFont(font);

	text.setCharacterSize(60);
	text.setString("GAME OVER");
	text.setPosition(WIDTH / 2, r.getPosition().y + text.getGlobalBounds().height * 1.5);
	window.draw(text);

	text.setCharacterSize(30);
	ss << "Final Score: " << score;
	text.setString(ss.str());
	ss.str("");
	text.move(0, text.getCharacterSize() + SIZE);
	window.draw(text);

	text.setCharacterSize(30);
	text.setString("Press ENTER to restart");
	text.move(0, text.getCharacterSize() + SIZE);
	window.draw(text);
}

void Game::renderIntro()
{
	if (logoTimer.getElapsedTime().asSeconds() > 0.5) {
		logoTimer.restart();
		logoCtr++;
	}

	sf::Sprite r;
	r.setTexture(textureManager.getTexture("tetromino"));
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < strlen(logo[0]); j++) {
			if (logo[i][j] == '#') {

				r.setTextureRect(texturePos[
					((logoCtr / 6) + ( std::ceil(j/4) <= logoCtr % 6 && 1)) % 7 + 1
					// set text color effect
				]);
				r.setPosition(j * r.getGlobalBounds().getSize().x, i * r.getGlobalBounds().getSize().y);
				r.move((WIDTH - (6 * 3 + 5) * r.getGlobalBounds().getSize().x) / 2, (10*r.getGlobalBounds().getSize().y));
				window.draw(r);
			}
		}
	}

	for (int i = 0; i < WIDTH / 20; i++) {
		r.setTextureRect(texturePos[0]);
		r.setPosition(i * r.getGlobalBounds().getSize().x, 6 * r.getGlobalBounds().getSize().y);
		window.draw(r);
		r.move(0, 12 * r.getGlobalBounds().getSize().y);
		window.draw(r);
	}

	DText text;
	text.setFont(font);
	text.setCharacterSize(32);
	text.setString("PRESS ENTER TO PLAY");
	text.setPosition(WIDTH / 2, HEIGHT * 3 / 4);
	window.draw(text);
}

void Game::newCurrent()
{
	current.move(0, -1);
	for (Point& t : current.mainT)
	{
		field[(int)t.y][(int)t.x] = current.type + 1;
	}

	current.setTetromino();

	if (field[0][4] != 0) {
		winstate = LOSE;
	}

	clearLines();
	DROP_COOLDOWN = DEFAULT_DROP_COOLDOWN;
}

void Game::clearLines()
{
	int l = 0;
	for (int i = 0; i < 20; ++i) {
		if (checkClear(i)) {
			l++;
			clear(i);
			for (int j = i; j > 0; j--) {
				int temp[10];
				std::copy(field[j], field[j] + 10, temp);
				std::copy(field[j-1], field[j-1] + 10, field[j]);
				std::copy(temp, temp + 10, field[j-1]);
			}

		}
	}

	switch (l) {
	case(1):
		score += 100 * level;
		scoreText = "SINGLE";
		break;
	case(2):
		score += 300 * level;
		scoreText = "DOUBLE";
		break;
	case(3):
		score += 500 * level;
		scoreText = "TRIPLE";
		break;
	case(4):
		score += 800 * level;
		scoreText = "TETRIS";
		break;
	}

	scoreTextTimer.restart();
}

bool Game::checkClear(int line)
{
	for (int i = 0; i < 10; ++i) {
		if (field[line][i] == 0) {
			return false;
		}
	}
	return true;
}

void Game::clear(int line) {
	for (int i = 0; i < 10; i++) {
		field[line][i] = 0;
	}
	lines_cleared++;
	level = (int)lines_cleared / 10 + 1;
	
	if (level > MAX_LEVEL) {
		level = MAX_LEVEL;
	}

	DEFAULT_DROP_COOLDOWN = MAX_DROP_COOLDOWN - (MAX_DROP_COOLDOWN-MIN_DROP_COOLDOWN)*(level-1)/(MAX_LEVEL-1);
}

void Game::reset()
{
	winstate = DEFAULT;
	lines_cleared = 0;
	level = 1;
	score = 0;
	for (int i = 0; i < ROWS; i++) {
		for (int j = 0; j < COLUMNS; j++) {
			field[i][j] = 0;
		}
	}
}