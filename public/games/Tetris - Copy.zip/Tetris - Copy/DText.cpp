#include "DText.h"

void DText::setString(const sf::String& string) {
	sf::Text::setString(string);
	auto center = this->getLocalBounds().getSize() / 2.f;
	auto localBounds = center + this->getLocalBounds().getPosition();
	auto rounded = roundBounds(localBounds);
	this->setOrigin(rounded);
}