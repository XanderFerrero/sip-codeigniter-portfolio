#include <SFML/Graphics.hpp>
#include "Game.h"

int main(int argc, char** argv) {
	Game game;
	game.start();

	return 0;
}