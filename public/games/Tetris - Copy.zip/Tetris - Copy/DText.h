#pragma once
#include "Global.hpp"

class DText: public sf::Text
{
public:
	void setString(const sf::String& string);
};

