#include "Current.h"

Current::Current()
{
	
	srand(time(NULL));
	nextType = (TM_TYPES)(rand() % 7);
}

Current::~Current(){}

void Current::setTetromino()
{
	type = nextType;
	nextType = (TM_TYPES)(rand() % 7);
	
	center.setBlock(centers[type][0][0], centers[type][0][1]);
	mainT[0].setBlock(center.x + centers[type][1][0], center.y + centers[type][1][1]);

	for (int i = 1; i < 4; i++) {
		mainT[i].setBlock(mainT[0].x + structure[type][i][0] - structure[type][0][0], mainT[0].y + structure[type][i][1] - structure[type][0][1]);
	}

	rState = R_STATE::R_SPAWN;
	std::copy(mainT, mainT + 4, ghostT);

	//shift to the top if spawnpoint overflows;
	if (tetroCollision()) {
		move(0, -1);
	}
}

void Current::move(float x, float y)
{
	center.x += x;
	center.y += y;

	for (int i = 0; i < 4; i++)
	{
		mainT[i].x += x;
		mainT[i].y += y;
		ghostT[i].x = mainT[i].x;
	}
}

void Current::drop()
{
	move(0, 1);
}

void Current::moveLeft()
{
	move(-1, 0);

	if (tetroCollision()) {
		move(1, 0);
	}

	//setGhostPos(field);
}

void Current::moveRight()
{
	move(1, 0);

	if (tetroCollision()) {
		move(-1, 0);
	}
	//setGhostPos(field);
}

void Current::rotateRight()
{
	rotate(1);
	wallKick(rState, (R_STATE)((4 + rState + 1) % 4), 1);
}

void Current::rotateLeft()
{
	rotate(0);
	wallKick(rState, (R_STATE)((4 + rState + -1) % 4), 0);

}

void Current::rotate(bool right)
{
	float temp = 0;

	for (int i = 0; i < 4; i++) {
		mainT[i].x -= center.x;
		mainT[i].y -= center.y;

		if(right){
			temp = mainT[i].x;
			mainT[i].x = -mainT[i].y;
		}
		else {
			temp = -mainT[i].x;
			mainT[i].x = mainT[i].y;
		}
		mainT[i].y = temp;

		mainT[i].x += center.x;
		mainT[i].y += center.y;

		ghostT[i].x = mainT[i].x;
		ghostT[i].y = mainT[i].y;
	}
}

bool Current::tetroCollision()
{
	for (Point& t : mainT) {
		if (field[(int)t.y][(int)t.x] != 0 || (t.x < 0 || t.x > COLUMNS - 1)) {
			return true;
		}
	}

	return false;
}

bool Current::groundCollision() {
	for (Point& t : mainT)
	{
		if ((t.y == ROWS || field[(int)t.y][(int)t.x] != 0))
		{
			return true;
		}
	}

	return false;
}

void Current::wallKick(R_STATE& init, R_STATE next, bool right)
{
	std::vector<std::vector<int>> data = getWallKickData(init, next);

	for (std::vector<int>& test : data)
	{
		// since data uses the first quadrant, move the tiles relative to the fourth quadrant

		move(test[0], -test[1]);

		if (!(tetroCollision() || groundCollision())) {
			init = next;
			return;
		}

		move(-test[0], test[1]);
	}

	rotate(!right);
}

void Current::setGhostPos()
{
	std::copy(mainT, mainT + 4, ghostT);
	while (1) {
		for (Point& b : ghostT)
		{
			if (b.y > ROWS - 1 || field[(int)b.y][(int)b.x] != 0) {
				for (Point& b : ghostT) {
					b.y -= 1;
				}
				return;
			}
		}

		for (Point& b : ghostT) {
			b.y += 1;
		}
	}
}

int Current::hardDrop()
{
	// score+= hard_drop_score * 2;
	int score = 0;
	while (1) {
		if (groundCollision()) return score;
		
		score++;
		for (Point& b : mainT) {
			b.y += 1;
		}
	}
}

std::vector<std::vector<int>> Current::getWallKickData(R_STATE& init, R_STATE next)
{
	if (type == TM_TYPES::I) {
		if (init == R_STATE::R_SPAWN && next == R_STATE::R_RIGHT)
		{
			return { {0,0},{-2,0},{1,0},{-2,-1},{1,2} };
		}
		else if (init == R_RIGHT && next == R_SPAWN)
		{
			return { {0,0},{2,0},{-1,0},{2,1},{-1,-2} };
		}
		else if (init == R_RIGHT && next == R_BACK)
		{
			return { {0,0},{-1,0},{2,0},{-1,2},{2,-1} };
		}
		else if (init == R_BACK && next == R_RIGHT)
		{
			return { {0,0},{1,0},{-2,0},{1,-2},{-2,1} };
		}
		else if (init == R_BACK && next == R_LEFT)
		{
			return { {0,0},{2,0},{-1,0},{2,1},{-1,-2} };
		}
		else if (init == R_LEFT && next == R_BACK)
		{
			return { {0,0},{-2,0},{1,0},{-2,-1},{1,2} };
		}
		else if (init == R_LEFT && next == R_SPAWN)
		{
			return { {0,0},{1,0},{-2,0},{1,-2},{-2,1} };
		}
		else if (init == R_SPAWN && next == R_LEFT)
		{
			return { {0,0},{-1,0},{2,0},{-1,2},{2,-1} };
		}
	}
	else {
		if (init == R_SPAWN && next == R_RIGHT)
		{
			return { {0,0},{-1,0},{-1,1},{0,-2},{-1,-2} };
		}
		else if (init == R_RIGHT && next == R_SPAWN)
		{
			return { {0,0},{1,0},{1,-1},{0,2},{1,2} };
		}
		else if (init == R_RIGHT && next == R_BACK)
		{
			return { {0,0},{1,0},{1,-1},{0,2},{1,2} };
		}
		else if (init == R_BACK && next == R_RIGHT)
		{
			return { {0,0},{-1,0},{-1,1},{0,-2},{-1,-2} };
		}
		else if (init == R_BACK && next == R_LEFT)
		{
			return { {0,0},{1,0},{1,1},{0,-2},{1,-2} };
		}
		else if (init == R_LEFT && next == R_BACK)
		{
			return { {0,0},{-1,0},{-1,-1},{0,2},{-1,2} };
		}
		else if (init == R_LEFT && next == R_SPAWN)
		{
			return { {0,0},{-1,0},{-1,-1},{0,2},{-1,2} };
		}
		else if (init == R_SPAWN && next == R_LEFT)
		{
			return { {0,0},{1,0},{1,1},{0,-2},{1,-2} };
		}

	}
}